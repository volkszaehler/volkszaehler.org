-- phpMyAdmin SQL Dump
-- version 3.3.5.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 11. September 2010 um 21:36
-- Server Version: 5.1.49
-- PHP-Version: 5.3.2-2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `volkszaehler`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `entities`
--

DROP TABLE IF EXISTS `entities`;
CREATE TABLE IF NOT EXISTS `entities` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `type` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entities_uuid_uniq` (`uuid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Daten für Tabelle `entities`
--

INSERT INTO `entities` (`id`, `uuid`, `type`, `class`) VALUES
(1, 'a301d8d0-903b-11df-94bb-d943d061b6a8', 'power', 'channel'),
(2, '99c4b540-9025-11df-8457-1d974d0a2aed', 'power', 'channel'),
(3, 'e1667740-9662-11df-b301-01e92d4b3942', 'group', 'aggregator'),
(4, 'd81facc0-966e-11df-9ba7-cdb480edfd96', 'group', 'aggregator'),
(5, '7aab2690-966f-11df-bc2b-0b307fe1be90', 'group', 'aggregator'),
(6, 'bda4a740-9662-11df-94c8-010787c77162', 'group', 'aggregator'),
(7, 'c48c2a90-9662-11df-acd6-972b5a34a506', 'group', 'aggregator');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `groups_channel`
--

DROP TABLE IF EXISTS `groups_channel`;
CREATE TABLE IF NOT EXISTS `groups_channel` (
  `group_id` smallint(6) NOT NULL,
  `channel_id` smallint(6) NOT NULL,
  PRIMARY KEY (`group_id`,`channel_id`),
  KEY `channel_id` (`channel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `groups_channel`
--

INSERT INTO `groups_channel` (`group_id`, `channel_id`) VALUES
(6, 1),
(7, 2);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `groups_groups`
--

DROP TABLE IF EXISTS `groups_groups`;
CREATE TABLE IF NOT EXISTS `groups_groups` (
  `parent_id` smallint(6) NOT NULL,
  `child_id` smallint(6) NOT NULL,
  PRIMARY KEY (`parent_id`,`child_id`),
  KEY `child_id` (`child_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `groups_groups`
--

INSERT INTO `groups_groups` (`parent_id`, `child_id`) VALUES
(6, 4),
(6, 5);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `properties`
--

DROP TABLE IF EXISTS `properties`;
CREATE TABLE IF NOT EXISTS `properties` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `entity_id` smallint(6) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_properties` (`id`,`name`),
  KEY `entity_id` (`entity_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Daten für Tabelle `properties`
--

INSERT INTO `properties` (`id`, `entity_id`, `name`, `value`) VALUES
(1, 1, 'title', 'S0-Zaehler'),
(2, 1, 'description', 'Nummer 1'),
(4, 1, 'resolution', '2000'),
(5, 2, 'title', 'S0-Zaehler'),
(6, 2, 'description', 'Nummer 2'),
(8, 2, 'resolution', '2000');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tokens`
--

DROP TABLE IF EXISTS `tokens`;
CREATE TABLE IF NOT EXISTS `tokens` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `entity_id` smallint(6) DEFAULT NULL,
  `token` varchar(255) NOT NULL,
  `valid` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tokens_token_uniq` (`token`),
  KEY `entity_id` (`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `tokens`
--


--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `groups_channel`
--
ALTER TABLE `groups_channel`
  ADD CONSTRAINT `groups_channel_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `entities` (`id`),
  ADD CONSTRAINT `groups_channel_ibfk_2` FOREIGN KEY (`channel_id`) REFERENCES `entities` (`id`);

--
-- Constraints der Tabelle `groups_groups`
--
ALTER TABLE `groups_groups`
  ADD CONSTRAINT `groups_groups_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `entities` (`id`),
  ADD CONSTRAINT `groups_groups_ibfk_2` FOREIGN KEY (`child_id`) REFERENCES `entities` (`id`);

--
-- Constraints der Tabelle `properties`
--
ALTER TABLE `properties`
  ADD CONSTRAINT `properties_ibfk_1` FOREIGN KEY (`entity_id`) REFERENCES `entities` (`id`);

--
-- Constraints der Tabelle `tokens`
--
ALTER TABLE `tokens`
  ADD CONSTRAINT `tokens_ibfk_1` FOREIGN KEY (`entity_id`) REFERENCES `entities` (`id`);
